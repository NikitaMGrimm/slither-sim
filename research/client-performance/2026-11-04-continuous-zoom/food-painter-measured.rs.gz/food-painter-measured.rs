//! Read-only pixel-space food commands with early and late insertion barriers.

use std::{collections::HashMap, error::Error, fmt};

use crate::state::Point;

use super::{
    BodyAlpha, BodyAsset, BodyBlend, BodyPaintQuality, BodyPaintView, BodyRect, FoodInstance,
    FoodPaintSnapshot, FoodPaintState, FoodPresentation, FoodSnapshot, FoodSource,
    MAX_RETAINED_FOODS, food::all_finite,
};

/// Seven calls per visible food in the full quality path.
pub const MAX_FOOD_PAINT_COMMANDS: usize = 7 * MAX_RETAINED_FOODS;

/// Inclusive absolute-world cull bounds retained by the parent across resets.
/// None on FoodPaintInput means no food calls, including before the first own draw.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FoodCullBounds {
    left: f64,
    right: f64,
    top: f64,
    bottom: f64,
}

impl FoodCullBounds {
    /// Validate explicitly retained left/right/top/bottom bounds.
    pub fn new(left: f64, right: f64, top: f64, bottom: f64) -> Result<Self, FoodPaintError> {
        if !all_finite(&[left, right, top, bottom]) || left > right || top > bottom {
            return Err(FoodPaintError::InvalidView);
        }
        Ok(Self {
            left,
            right,
            top,
            bottom,
        })
    }

    /// Compute fixed 24-world-unit margins from the already prepared draw view.
    /// Call only at the parent's own-object camera point, never to advance a draw.
    pub fn from_view(view: BodyPaintView) -> Result<Self, FoodPaintError> {
        validate_view(view)?;
        let x = view.half_width / view.zoom + 24.;
        let y = view.half_height / view.zoom + 24.;
        Self::new(
            view.camera.x - x,
            view.camera.x + x,
            view.camera.y - y,
            view.camera.y + y,
        )
    }

    /// Copy left, right, top, bottom, without recomputing the retained view.
    pub fn limits(self) -> [f64; 4] {
        [self.left, self.right, self.top, self.bottom]
    }

    pub(super) fn contains(self, point: Point) -> bool {
        point.x >= self.left
            && point.x <= self.right
            && point.y >= self.top
            && point.y <= self.bottom
    }
}

/// Distinct scoped food passes; never regroup commands by source or opacity.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FoodPaintPass {
    /// All outlines precede every body call.
    Outline,
    /// Additive body calls after the outline barrier.
    Body,
    /// Two inner calls immediately before this food's two outer calls.
    InnerGlow,
    /// Completes one food before moving to the preceding dense-vector entry.
    OuterGlow,
}

/// Exact Canvas overload intent, in pixels with the identity transform.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum FoodImageDraw {
    /// Three-argument drawImage(source, x, y); natural source extent is retained.
    Whole {
        /// Destination left in backing-canvas pixels.
        x: f64,
        /// Destination top in backing-canvas pixels.
        y: f64,
    },
    /// Nine-argument drawImage with explicit declared source and destination sizes.
    Scaled {
        /// Full declared numeric source rectangle, starting at zero.
        source: BodyRect,
        /// Pixel destination; zero size is preserved as a call.
        destination: BodyRect,
    },
}

/// One immutable planned image call; no arbitrary caller commands enter the model.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FoodImageCommand {
    /// Sequence across early then late calls, ignoring the intervening snake work.
    pub sequence: usize,
    /// Current dense index, unrelated to instance identity or packed key.
    pub food_index: usize,
    /// Stable food identity for diagnostics.
    pub instance: FoodInstance,
    /// Exact insertion pass.
    pub pass: FoodPaintPass,
    /// Retained source identity, revision and numeric metadata.
    pub source: FoodSource,
    /// Whole-source or explicit scaled Canvas overload.
    pub draw: FoodImageDraw,
    /// Canvas requested/effective assignment, using retention rather than clamping.
    pub alpha: BodyAlpha,
    /// Source-over for outlines, lighter for every other food call.
    pub blend: BodyBlend,
}

/// Exact command and visibility counts, available only on complete validation.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct FoodPaintCounts {
    /// Distinct foods inside the cull rectangle that emit image commands.
    pub visible_foods: usize,
    /// Same inclusive cull rectangle before zoom attenuation; not image calls.
    /// Continuous zoom retains all of these foods; the field name also supports
    /// historical benchmark receipts that used subpixel omission.
    #[cfg(feature = "frame-bench")]
    pub before_zoom_foods: usize,
    /// Outline and body calls before all snake work.
    pub early: usize,
    /// Inner and outer glow calls after all snake eyes.
    pub late: usize,
}

impl FoodPaintCounts {
    /// Total image calls charged against the caller's combined frame budget.
    pub fn total(self) -> usize {
        self.early + self.late
    }
}

/// Complete food plan. Save/restore each pass's alpha/composition scope and use
/// identity pixel coordinates. Insert all snake work between early and late.
#[derive(Clone, Debug, PartialEq)]
pub struct FoodPaintPlan {
    /// Reverse-order outlines, then reverse-order bodies.
    pub early: Vec<FoodImageCommand>,
    /// Early index immediately after all outlines; begin the lighter body scope.
    pub outline_barrier: usize,
    /// Reverse-order foods, with each food's inner/inner/outer/outer calls together.
    pub late: Vec<FoodImageCommand>,
    /// Exact counts; the planner never silently drops over-budget foods.
    pub counts: FoodPaintCounts,
}

/// Coherent frozen draw inputs. Planning changes no clocks, assets or food state.
#[derive(Clone, Copy, Debug)]
pub struct FoodPaintInput<'a> {
    /// Retained dense order, borrowed directly from FoodWorld::foods().
    pub foods: &'a [FoodPresentation],
    /// Final already prepared camera, zoom and canvas center.
    pub view: BodyPaintView,
    /// Borrowed applied desktop quality; no quality evolution occurs here.
    pub quality: BodyPaintQuality,
    /// Caller-retained bounds; never initialized means no image calls.
    pub bounds: Option<FoodCullBounds>,
    /// Current coherent source snapshots, revalidated against frozen identities.
    /// The parent must retain actual source objects and check native readiness
    /// again after callbacks and before resetting/submitting to Canvas.
    pub assets: &'a [BodyAsset],
    /// Target identity when known; any food source alias is rejected.
    pub target_handle: Option<u64>,
    /// Valid Canvas globalAlpha on entry to each scoped food pass.
    pub entry_alpha: f64,
    /// Remaining image budget for the combined frame, supplied by its owner.
    pub command_limit: usize,
}

/// Complete input, source, arithmetic or allocation failure; no partial plan escapes.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FoodPaintError {
    /// Invalid view or retained cull bounds.
    InvalidView,
    /// Invalid quality blend or scoped entry alpha.
    InvalidVisual,
    /// Retained food count exceeds the native domain.
    FoodLimit,
    /// A frozen source is missing, changed or unready in the current catalog.
    InvalidSource,
    /// A retained source aliases the destination canvas.
    TargetAlias,
    /// The complete food count exceeds the remaining combined or hard budget.
    CommandLimit,
    /// A command's distance, center or rectangle became nonfinite.
    Arithmetic,
    /// Reserving the complete command vectors failed.
    Allocation,
}

impl fmt::Display for FoodPaintError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "food paint planning failed: {self:?}")
    }
}
impl Error for FoodPaintError {}

/// Reusable current-catalog lookup for hosts retaining their asset tables.
/// Storage is bounded by catalog size, independent of food count or handle values.
#[derive(Debug, Default)]
pub struct FoodAssetIndex {
    assets: Vec<BodyAsset>,
    by_handle: HashMap<u64, Option<usize>>,
}

impl FoodAssetIndex {
    fn refresh(&mut self, assets: &[BodyAsset]) -> Result<(), FoodPaintError> {
        if self.assets == assets {
            return Ok(());
        }
        // Public caller-owned tables may change in place. Compare once per plan,
        // then rebuild only on change: four full scans per retained food otherwise
        // dominate dense native pictures (docs/frame-performance.md CPU workload).
        let mut next = Self::default();
        next.assets
            .try_reserve_exact(assets.len())
            .map_err(|_| FoodPaintError::Allocation)?;
        next.by_handle
            .try_reserve(assets.len())
            .map_err(|_| FoodPaintError::Allocation)?;
        next.assets.extend_from_slice(assets);
        for (i, asset) in assets.iter().enumerate() {
            next.by_handle
                .entry(asset.handle)
                .and_modify(|entry| {
                    // Identical duplicates are valid; any conflicting duplicate
                    // invalidates this handle, but must not reject unused handles.
                    if entry.is_some_and(|first| assets[first] != *asset) {
                        *entry = None;
                    }
                })
                .or_insert(Some(i));
        }
        // Replacing rather than retaining old capacities also bounds a shrinking
        // catalog; unchanged frames allocate nothing for validation.
        *self = next;
        Ok(())
    }

    fn matches(&self, frozen: BodyAsset) -> bool {
        self.by_handle
            .get(&frozen.handle)
            .copied()
            .flatten()
            .is_some_and(|i| self.assets[i] == frozen)
    }
}

fn validate_view(view: BodyPaintView) -> Result<(), FoodPaintError> {
    if !all_finite(&[
        view.camera.x,
        view.camera.y,
        view.zoom,
        view.half_width,
        view.half_height,
    ]) || view.zoom <= 0.
        || view.half_width <= 0.
        || view.half_height <= 0.
    {
        return Err(FoodPaintError::InvalidView);
    }
    Ok(())
}

fn validate(
    input: FoodPaintInput<'_>,
    mut index: Option<&mut FoodAssetIndex>,
) -> Result<(), FoodPaintError> {
    validate_view(input.view)?;
    if !(0. ..=1.).contains(&input.quality.blend) || !(0. ..=1.).contains(&input.entry_alpha) {
        return Err(FoodPaintError::InvalidVisual);
    }
    if input.foods.len() > MAX_RETAINED_FOODS {
        return Err(FoodPaintError::FoodLimit);
    }
    if let Some(index) = &mut index {
        index.refresh(input.assets)?;
    }
    for food in input.foods {
        let food = food.snapshot();
        let sources = food.sources;
        for source in [sources.body, sources.outline, sources.inner, sources.outer] {
            source
                .validate()
                .map_err(|_| FoodPaintError::InvalidSource)?;
            let frozen = source.asset();
            if input.target_handle == Some(frozen.handle) {
                return Err(FoodPaintError::TargetAlias);
            }
            if let Some(index) = &index {
                if !index.matches(frozen) {
                    return Err(FoodPaintError::InvalidSource);
                }
                continue;
            }
            let mut found = false;
            for actual in input.assets.iter().filter(|a| a.handle == frozen.handle) {
                if *actual != frozen {
                    return Err(FoodPaintError::InvalidSource);
                }
                found = true;
            }
            if !found {
                return Err(FoodPaintError::InvalidSource);
            }
        }
    }
    Ok(())
}

/// Exact Canvas overload and rectangle policy for one already selected food image.
#[inline(always)]
pub fn food_image_draw(
    source: FoodSource,
    center: Point,
    scale: f64,
    zoom_factor: f64,
) -> Result<FoodImageDraw, FoodPaintError> {
    let stock_whole = scale == 1.;
    let draw = if stock_whole && zoom_factor == 1. {
        FoodImageDraw::Whole {
            x: center.x - source.half_width(),
            y: center.y - source.half_height(),
        }
    } else {
        // Scale the stock overload, not its branch condition. Whole-source
        // draws use natural raster dimensions; scaled draws retain their
        // declared crop even if scale * user zoom happens to equal one.
        let [width, height] = if stock_whole {
            [
                f64::from(source.asset().width),
                f64::from(source.asset().height),
            ]
        } else {
            [source.width(), source.height()]
        };
        FoodImageDraw::Scaled {
            source: BodyRect {
                x: 0.,
                y: 0.,
                width,
                height,
            },
            destination: BodyRect {
                x: center.x - source.half_width() * scale * zoom_factor,
                y: center.y - source.half_height() * scale * zoom_factor,
                width: width * scale * zoom_factor,
                height: height * scale * zoom_factor,
            },
        }
    };
    let finite = match draw {
        FoodImageDraw::Whole { x, y } => all_finite(&[x, y]),
        FoodImageDraw::Scaled { destination: d, .. } => all_finite(&[d.x, d.y, d.width, d.height]),
    };
    if !finite {
        return Err(FoodPaintError::Arithmetic);
    }
    Ok(draw)
}

struct Recorder<F> {
    emit: F,
    counts: FoodPaintCounts,
    limit: usize,
    previous_alpha: f64,
    zoom_factor: f64,
    pixels_per_unit: f64,
}

fn alpha_assignment(requested: f64, previous: f64) -> BodyAlpha {
    let accepted = (0. ..=1.).contains(&requested);
    BodyAlpha {
        requested,
        effective: if accepted { requested } else { previous },
        accepted,
    }
}

impl<F: FnMut(FoodImageCommand)> Recorder<F> {
    fn image(
        &mut self,
        food: FoodSnapshot,
        index: usize,
        pass: FoodPaintPass,
        source: FoodSource,
        center: Point,
        alpha: f64,
    ) -> Result<(), FoodPaintError> {
        // Keep Canvas's assignment rule explicit even though valid food state
        // normally requests bounded alpha. Do not clamp or elide zero calls.
        let alpha = alpha_assignment(alpha, self.previous_alpha);
        let (draw, gain) = super::continuous_food_image(
            source,
            center,
            food.scale,
            self.zoom_factor,
            self.pixels_per_unit,
        )?;
        let alpha = BodyAlpha {
            requested: alpha.requested * gain,
            effective: alpha.effective * gain,
            ..alpha
        };
        let sequence = self.counts.total();
        if sequence >= self.limit || sequence >= MAX_FOOD_PAINT_COMMANDS {
            return Err(FoodPaintError::CommandLimit);
        }
        let early = matches!(pass, FoodPaintPass::Outline | FoodPaintPass::Body);
        let command = FoodImageCommand {
            sequence,
            food_index: index,
            instance: food.instance,
            pass,
            source,
            draw,
            alpha,
            blend: if pass == FoodPaintPass::Outline {
                BodyBlend::SourceOver
            } else {
                BodyBlend::Lighter
            },
        };
        if early {
            self.counts.early += 1;
        } else {
            self.counts.late += 1;
        }
        self.previous_alpha = alpha.effective;
        (self.emit)(command);
        Ok(())
    }
}

/// The unchanged pulse term shared by the body and both glow pairs.
#[inline(always)]
pub fn food_pulse(food: impl Into<FoodPaintState>) -> f64 {
    let food = food.into();
    0.5 + 0.5 * (food.animation_phase / 13.).cos()
}

/// Backing-pixel body/outline centre for an already prepared view.
#[inline(always)]
pub fn food_body_center(food: impl Into<FoodPaintState>, view: BodyPaintView) -> Point {
    let food = food.into();
    Point {
        x: view.half_width + view.zoom * (food.render_position.x - view.camera.x),
        y: view.half_height + view.zoom * (food.render_position.y - view.camera.y),
    }
}

/// Requested base and pulse body alpha, before Canvas assignment retention.
#[inline(always)]
pub fn food_body_alpha(food: impl Into<FoodPaintState>, blend: f64, pulse: f64) -> [f64; 2] {
    let food = food.into();
    [
        food.fade,
        (if blend == 1. { 1. } else { blend }) * pulse * food.fade,
    ]
}

/// Source, backing-pixel centre and requested alphas of one additive glow pair.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FoodGlowPaint {
    /// Frozen inner or outer glow source.
    pub source: FoodSource,
    /// Pixel-space centre after the core's distance-dependent offset.
    pub center: Point,
    /// Requested base and pulse alpha, in their original multiplication order.
    pub alpha: [f64; 2],
}

/// Shared glow policy; preserve the multiplication order before f32 projection.
/// Callers supply the same pulse once per food; view/quality admission is theirs.
#[inline(always)]
pub fn food_glow_paint(
    food: impl Into<FoodPaintSnapshot>,
    view: BodyPaintView,
    outer: bool,
    blend: f64,
    pulse: f64,
) -> Result<FoodGlowPaint, FoodPaintError> {
    let paint = food.into();
    let food = paint.animation;
    let sources = paint.sources;
    let dx = food.render_position.x - view.camera.x;
    let dy = food.render_position.y - view.camera.y;
    let distance = dx * dx + dy * dy;
    if !distance.is_finite() {
        return Err(FoodPaintError::Arithmetic);
    }
    let (source, shift, mut alpha) = if outer {
        (
            sources.outer,
            0.32,
            0.085 * (1. - distance / (16500. + distance)),
        )
    } else {
        (
            sources.inner,
            0.06,
            0.005 + 0.09 * (1. - distance / (86000. + distance)),
        )
    };
    let t = 1. + shift * food.scale;
    let center = Point {
        x: dx * t * view.zoom + view.half_width,
        y: dy * t * view.zoom + view.half_height,
    };
    if food.scale != 1. {
        alpha *= food.scale.powf(0.25);
    }
    if blend != 1. {
        alpha *= blend;
    }
    Ok(FoodGlowPaint {
        source,
        center,
        alpha: [alpha * food.fade, alpha * pulse * food.fade],
    })
}

fn generate<F: FnMut(FoodImageCommand)>(
    input: FoodPaintInput<'_>,
    zoom_factor: f64,
    pixels_per_unit: f64,
    emit: F,
) -> Result<FoodPaintCounts, FoodPaintError> {
    let mut recorder = Recorder {
        emit,
        counts: FoodPaintCounts::default(),
        limit: input.command_limit,
        previous_alpha: input.entry_alpha,
        zoom_factor,
        pixels_per_unit: pixels_per_unit,
    };
    let Some(bounds) = input.bounds else {
        return Ok(recorder.counts);
    };
    let q = input.quality;
    let v = input.view;
    let detailed = q.high_quality || q.blend > 0.;
    let in_bounds = || {
        input
            .foods
            .iter()
            .enumerate()
            .rev()
            .map(|(i, food)| (i, food.snapshot()))
            .filter(|(_, f)| bounds.contains(f.render_position))
    };
    for (index, food) in in_bounds() {
        #[cfg(feature = "frame-bench")]
        {
            recorder.counts.before_zoom_foods += 1;
        }
        let center = food_body_center(food, v);
        recorder.image(
            food,
            index,
            FoodPaintPass::Outline,
            food.sources.outline,
            center,
            0.8 * food.fade,
        )?;
        recorder.counts.visible_foods += 1;
    }
    recorder.previous_alpha = input.entry_alpha;
    for (index, food) in in_bounds() {
        let center = food_body_center(food, v);
        recorder.image(
            food,
            index,
            FoodPaintPass::Body,
            food.sources.body,
            center,
            food.fade,
        )?;
        if detailed {
            let alpha = food_body_alpha(food, q.blend, food_pulse(food))[1];
            recorder.image(
                food,
                index,
                FoodPaintPass::Body,
                food.sources.body,
                center,
                alpha,
            )?;
        }
    }
    recorder.previous_alpha = input.entry_alpha;
    if detailed {
        for (index, food) in in_bounds() {
            let pulse = food_pulse(food);
            for (pass, outer) in [
                (FoodPaintPass::InnerGlow, false),
                (FoodPaintPass::OuterGlow, true),
            ] {
                let glow = food_glow_paint(food, v, outer, q.blend, pulse)?;
                recorder.image(food, index, pass, glow.source, glow.center, glow.alpha[0])?;
                recorder.image(food, index, pass, glow.source, glow.center, glow.alpha[1])?;
            }
        }
    }
    Ok(recorder.counts)
}

/// Validate every retained source and preflight all numeric commands and the
/// complete remaining budget before allocating output. Returned early/late
/// barriers are mandatory. Later Canvas submission and model commit are owned
/// by the parent; failed submission does not promise pixel rollback.
pub fn plan_food(input: FoodPaintInput<'_>) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_with_storage(input, Vec::new(), Vec::new())
}

/// Reuse retired early/late commands without changing validation or paint barriers.
pub fn plan_food_with_storage(
    input: FoodPaintInput<'_>,
    early: Vec<FoodImageCommand>,
    late: Vec<FoodImageCommand>,
) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_impl(input, early, late, 1., 1., None)
}

/// Reuse command storage and a catalog-sized index. Every call checks for table
/// changes before validating all retained sources, including culled food.
pub fn plan_food_with_index(
    input: FoodPaintInput<'_>,
    index: &mut FoodAssetIndex,
    early: Vec<FoodImageCommand>,
    late: Vec<FoodImageCommand>,
) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_impl(input, early, late, 1., 1., Some(index))
}

/// Opt-in wheel projection of stock sprites, with subpixel-food LOD.
pub fn plan_food_with_zoom(
    input: FoodPaintInput<'_>,
    early: Vec<FoodImageCommand>,
    late: Vec<FoodImageCommand>,
    zoom_factor: f64,
) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_impl(input, early, late, zoom_factor, 1., None)
}

/// Combine wheel projection/LOD with a retained catalog-sized source index.
/// Factor one has the same retained-source validation and commands as the stock
/// indexed path. Table changes are checked before each plan (docs/zoom.md).
pub fn plan_food_with_zoom_and_index(
    input: FoodPaintInput<'_>,
    index: &mut FoodAssetIndex,
    early: Vec<FoodImageCommand>,
    late: Vec<FoodImageCommand>,
    zoom_factor: f64,
) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_impl(input, early, late, zoom_factor, 1., Some(index))
}

/// Local look prototype: physical-pixel floor for each food source independently.
pub fn plan_food_with_zoom_and_density(
    input: FoodPaintInput<'_>,
    index: &mut FoodAssetIndex,
    early: Vec<FoodImageCommand>,
    late: Vec<FoodImageCommand>,
    factor: f64,
    density: f64,
) -> Result<FoodPaintPlan, FoodPaintError> {
    plan_food_impl(input, early, late, factor, density, Some(index))
}

/// Validate frozen inputs and sources without materializing image commands.
/// Retained renderers must still preflight their complete numeric output and
/// preserve the early/late barriers before publishing a picture.
pub fn validate_food_with_index(
    input: FoodPaintInput<'_>,
    index: &mut FoodAssetIndex,
    zoom_factor: f64,
) -> Result<(), FoodPaintError> {
    if !zoom_factor.is_finite() || zoom_factor <= 0. {
        return Err(FoodPaintError::InvalidView);
    }
    validate(input, Some(index))
}

fn plan_food_impl(
    input: FoodPaintInput<'_>,
    mut early: Vec<FoodImageCommand>,
    mut late: Vec<FoodImageCommand>,
    zoom_factor: f64,
    pixels_per_unit: f64,
    index: Option<&mut FoodAssetIndex>,
) -> Result<FoodPaintPlan, FoodPaintError> {
    if !zoom_factor.is_finite()
        || zoom_factor <= 0.
        || !pixels_per_unit.is_finite()
        || pixels_per_unit <= 0.
    {
        return Err(FoodPaintError::InvalidView);
    }
    validate(input, index)?;
    let counts = generate(input, zoom_factor, pixels_per_unit, |_| {})?;
    early.clear();
    late.clear();
    early
        .try_reserve_exact(counts.early)
        .map_err(|_| FoodPaintError::Allocation)?;
    late.try_reserve_exact(counts.late)
        .map_err(|_| FoodPaintError::Allocation)?;
    generate(input, zoom_factor, pixels_per_unit, |command| {
        if matches!(command.pass, FoodPaintPass::Outline | FoodPaintPass::Body) {
            early.push(command);
        } else {
            late.push(command);
        }
    })?;
    Ok(FoodPaintPlan {
        early,
        outline_barrier: counts.visible_foods,
        late,
        counts,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn index_storage_tracks_catalog_size_and_is_reused_without_changes() {
        let assets: Vec<_> = (0..1024)
            .map(|i| BodyAsset {
                handle: u64::MAX - i,
                revision: 1,
                width: 1,
                height: 1,
                status: super::super::BodyAssetStatus::Ready,
            })
            .collect();
        let mut index = FoodAssetIndex::default();
        index.refresh(&assets).unwrap();
        assert_eq!(index.assets.len(), assets.len());
        assert!(index.by_handle.len() <= assets.len());
        let pointer = index.assets.as_ptr();
        let capacities = (index.assets.capacity(), index.by_handle.capacity());
        for _ in 0..100 {
            index.refresh(&assets.clone()).unwrap();
            assert_eq!(index.assets.as_ptr(), pointer);
            assert_eq!(
                (index.assets.capacity(), index.by_handle.capacity()),
                capacities
            );
            assert!(index.matches(assets[0]));
        }
        index.refresh(&assets[..1]).unwrap();
        assert_eq!(index.assets.len(), 1);
        assert_eq!(index.by_handle.len(), 1);
        assert!(index.assets.capacity() < capacities.0);
        assert!(index.by_handle.capacity() < capacities.1);
        assert!(!index.matches(assets[1]));
        index.refresh(&[]).unwrap();
        assert_eq!(index.assets.capacity(), 0);
        assert_eq!(index.by_handle.capacity(), 0);
    }

    #[test]
    fn canvas_ignores_invalid_alpha_assignments_and_accepts_signed_zero() {
        for requested in [-0.1, 1.1, f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let result = alpha_assignment(requested, 0.375);
            assert!(!result.accepted);
            assert_eq!(result.requested.to_bits(), requested.to_bits());
            assert_eq!(result.effective, 0.375);
        }
        for requested in [-0., 0., 0.5, 1.] {
            let result = alpha_assignment(requested, 0.375);
            assert!(result.accepted);
            assert_eq!(result.effective.to_bits(), requested.to_bits());
        }
    }
}
